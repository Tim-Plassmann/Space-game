

public interface IMovementControls
{
    float YawAmount { get; }
    float PitchAmount { get; }
    float RollAmount { get; }
    float ThrustAmount { get; }
}




