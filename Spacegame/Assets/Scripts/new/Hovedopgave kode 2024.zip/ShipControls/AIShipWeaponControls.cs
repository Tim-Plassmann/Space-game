using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIShipWeaponControlls : WeaponControllsBase
{
    public override bool PrimaryFired => false;
    public override bool SecondaryFired => false;
}
